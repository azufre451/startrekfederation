$(function(){
var openmenu=null;
$("div.mega").addClass("open").slideUp(0);
$("#nav>li:has('div.mega')").hoverIntent(
    function(){if(openmenu!=null && openmenu!=this)$("div.mega",openmenu).slideUp(10);$("div.mega",this).slideDown("slow");openmenu=this;},
    function(){$("div.mega",this).slideUp("fast");});
});